package com.example.finalproject;

public class Receive {
}
